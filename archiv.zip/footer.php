
<footer>
	<center><br><p>Footer<br>
	Your Footer Text here</p></center>
</footer>
